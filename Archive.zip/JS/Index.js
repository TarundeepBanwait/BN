function openPic(picName) {
    var i;
    var x = document.getElementsByClassName("picture");
    for (i = 0; i < x.length; i++) {
        x[i].style.display = "none";
    }
    document.getElementById(picName).style.display = "block";
}

var header = document.getElementById("port-btn");
var btns = header.getElementsByClassName("button");
for (var i = 0; i < btns.length; i++) {
    btns[i].addEventListener("click", function () {
        var current = document.getElementsByClassName("abc");
        current[0].className = current[0].className.replace(" abc", "");
        this.className += " abc";
    });
}


// counter 1


const counters = document.querySelectorAll('.value');
const speed = 200;

counters.forEach(counter => {
    const animate = () => {
        const value = +counter.getAttribute('akhi');
        const data = +counter.innerText;

        const time = value / speed;
        if (data < value) {
            counter.innerText = Math.ceil(data + time);
            setTimeout(animate, 50);
        } else {
            counter.innerText = value;
        }

    }

    animate();
});



    AOS.init(
        {
            offset: 250,
            duration: 900,
        }
    );
